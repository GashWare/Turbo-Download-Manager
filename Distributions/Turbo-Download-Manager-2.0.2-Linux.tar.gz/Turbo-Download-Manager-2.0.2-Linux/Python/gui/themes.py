"""
Theme and Color Palette Definitions for Turbo Download Manager.
Provides 6 rich, carefully crafted themes:
- Dark (Default Modern Cyber Slate)
- Light (Modern Clean Slate Light)
- Cyberpunk (Night City Neon Yellow, Cyan & Pink)
- Neon (Synthwave Electric Purple & Cyan)
- Neo Tokyo (Tokyo Midnight Aqua & Crimson)
- Matrix (Terminal Phosphor Green & Obsidian)
"""

from __future__ import annotations
from typing import Dict, Any

THEMES: Dict[str, Dict[str, Any]] = {
    "dark": {
        "display_name": "Dark",
        "ctk_mode": "dark",
        "bg_main": "#0f1015",
        "toolbar_bg": "#181a20",
        "sidebar_bg": "#121316",
        "card_bg": "#181a20",
        "card_border": "#2b2d35",
        "card_border_width": 1,
        "text_primary": "#ffffff",
        "text_secondary": "#a0a5b5",
        "text_muted": "#6c7280",
        "accent": "#00b4d8",
        "accent_hover": "#0096c7",
        "accent_text": "#ffffff",
        "btn_bg": "#2b2d35",
        "btn_hover": "#383a45",
        "btn_text": "#ffffff",
        "btn_open_bg": "#2ec4b6",
        "btn_open_hover": "#249c90",
        "btn_open_text": "#0d1117",
        "btn_cancel_bg": "#3a1c1c",
        "btn_cancel_hover": "#5a2222",
        "btn_cancel_text": "#ff6b6b",
        "btn_border_width": 0,
        "btn_border_color": "#2b2d35",
        "progress_bg": "#2b2d42",
        "progress_fill": "#00b4d8",
        "completed_fill": "#2ec4b6",
        "paused_fill": "#e76f51",
        "error_fill": "#e63946",
        "badge_downloading": "#00b4d8",
        "badge_completed": "#2ec4b6",
        "badge_paused": "#e76f51",
        "badge_error": "#e63946",
        "badge_queued": "#90a4ae",
        "badge_connecting": "#f39c12",
        "badge_cancelled": "#78909c",
        "matrix_rain": False,
    },
    "light": {
        "display_name": "Light",
        "ctk_mode": "light",
        "bg_main": "#e2e8f0",
        "toolbar_bg": "#f1f5f9",
        "sidebar_bg": "#cbd5e1",
        "card_bg": "#f8fafc",
        "card_border": "#94a3b8",
        "card_border_width": 1,
        "text_primary": "#0f172a",
        "text_secondary": "#334155",
        "text_muted": "#64748b",
        "accent": "#0284c7",
        "accent_hover": "#0369a1",
        "accent_text": "#ffffff",
        "btn_bg": "#cbd5e1",
        "btn_hover": "#94a3b8",
        "btn_text": "#0f172a",
        "btn_open_bg": "#10b981",
        "btn_open_hover": "#059669",
        "btn_open_text": "#ffffff",
        "btn_cancel_bg": "#fecaca",
        "btn_cancel_hover": "#f87171",
        "btn_cancel_text": "#b91c1c",
        "btn_border_width": 0,
        "btn_border_color": "#cbd5e1",
        "progress_bg": "#cbd5e1",
        "progress_fill": "#0284c7",
        "completed_fill": "#10b981",
        "paused_fill": "#ea580c",
        "error_fill": "#dc2626",
        "badge_downloading": "#0284c7",
        "badge_completed": "#10b981",
        "badge_paused": "#ea580c",
        "badge_error": "#dc2626",
        "badge_queued": "#64748b",
        "badge_connecting": "#d97706",
        "badge_cancelled": "#94a3b8",
        "matrix_rain": False,
    },
    "cyberpunk": {
        "display_name": "Cyberpunk",
        "ctk_mode": "dark",
        "bg_main": "#0b0c10",
        "toolbar_bg": "#13141c",
        "sidebar_bg": "#0f1017",
        "card_bg": "#161824",
        "card_border": "#fcee0a",
        "card_border_width": 1,
        "text_primary": "#fcee0a",
        "text_secondary": "#00f0ff",
        "text_muted": "#6c7280",
        "accent": "#fcee0a",
        "accent_hover": "#e6d705",
        "accent_text": "#0b0c10",
        "btn_bg": "#222533",
        "btn_hover": "#2f3346",
        "btn_text": "#00f0ff",
        "btn_open_bg": "#00f0ff",
        "btn_open_hover": "#00c8d6",
        "btn_open_text": "#0b0c10",
        "btn_cancel_bg": "#3a0a14",
        "btn_cancel_hover": "#5e1020",
        "btn_cancel_text": "#ff003c",
        "btn_border_width": 0,
        "btn_border_color": "#222533",
        "progress_bg": "#222533",
        "progress_fill": "#00f0ff",
        "completed_fill": "#fcee0a",
        "paused_fill": "#ff5400",
        "error_fill": "#ff003c",
        "badge_downloading": "#00f0ff",
        "badge_completed": "#fcee0a",
        "badge_paused": "#ff5400",
        "badge_error": "#ff003c",
        "badge_queued": "#70758a",
        "badge_connecting": "#ffaa00",
        "badge_cancelled": "#4a4e5d",
        "matrix_rain": False,
    },
    "neon": {
        "display_name": "Neon",
        "ctk_mode": "dark",
        "bg_main": "#0c0714",
        "toolbar_bg": "#160e24",
        "sidebar_bg": "#110a1c",
        "card_bg": "#1c122e",
        "card_border": "#7209b7",
        "card_border_width": 1,
        "text_primary": "#f72585",
        "text_secondary": "#4cc9f0",
        "text_muted": "#7a6b94",
        "accent": "#b5179e",
        "accent_hover": "#7209b7",
        "accent_text": "#ffffff",
        "btn_bg": "#271842",
        "btn_hover": "#392361",
        "btn_text": "#4cc9f0",
        "btn_open_bg": "#4cc9f0",
        "btn_open_hover": "#36a3c4",
        "btn_open_text": "#0c0714",
        "btn_cancel_bg": "#3d0c24",
        "btn_cancel_hover": "#61143a",
        "btn_cancel_text": "#ff4d6d",
        "btn_border_width": 0,
        "btn_border_color": "#271842",
        "progress_bg": "#271842",
        "progress_fill": "#f72585",
        "completed_fill": "#4cc9f0",
        "paused_fill": "#f77f00",
        "error_fill": "#d90429",
        "badge_downloading": "#f72585",
        "badge_completed": "#4cc9f0",
        "badge_paused": "#f77f00",
        "badge_error": "#d90429",
        "badge_queued": "#7209b7",
        "badge_connecting": "#b5179e",
        "badge_cancelled": "#483660",
        "matrix_rain": False,
    },
    "neo_tokyo": {
        "display_name": "Neo Tokyo",
        "ctk_mode": "dark",
        "bg_main": "#01012b",
        "toolbar_bg": "#05053b",
        "sidebar_bg": "#030330",
        "card_bg": "#0d0d4d",
        "card_border": "#ff2a6d",
        "card_border_width": 1,
        "text_primary": "#05d9e8",
        "text_secondary": "#ff2a6d",
        "text_muted": "#5e5ebb",
        "accent": "#ff2a6d",
        "accent_hover": "#d91e56",
        "accent_text": "#ffffff",
        "btn_bg": "#181861",
        "btn_hover": "#26268f",
        "btn_text": "#05d9e8",
        "btn_open_bg": "#01ffc3",
        "btn_open_hover": "#00d6a3",
        "btn_open_text": "#01012b",
        "btn_cancel_bg": "#380b22",
        "btn_cancel_hover": "#5c1338",
        "btn_cancel_text": "#ff2a6d",
        "btn_border_width": 0,
        "btn_border_color": "#181861",
        "progress_bg": "#181861",
        "progress_fill": "#05d9e8",
        "completed_fill": "#01ffc3",
        "paused_fill": "#ff9f1c",
        "error_fill": "#ff2a6d",
        "badge_downloading": "#05d9e8",
        "badge_completed": "#01ffc3",
        "badge_paused": "#ff9f1c",
        "badge_error": "#ff2a6d",
        "badge_queued": "#5e5ebb",
        "badge_connecting": "#d100d1",
        "badge_cancelled": "#33336b",
        "matrix_rain": False,
    },
    "matrix": {
        "display_name": "Matrix",
        "ctk_mode": "dark",
        "bg_main": "#020b05",
        "toolbar_bg": "#05170a",
        "sidebar_bg": "#031007",
        "card_bg": "#08210f",
        "card_border": "#00ff41",
        "card_border_width": 1,
        "text_primary": "#00ff41",
        "text_secondary": "#55ff88",
        "text_muted": "#1a5c28",
        "accent": "#00ff41",
        "accent_hover": "#00cc33",
        "accent_text": "#020b05",
        "btn_bg": "#0c2e15",
        "btn_hover": "#134720",
        "btn_text": "#00ff41",
        "btn_open_bg": "#39ff14",
        "btn_open_hover": "#2ecc11",
        "btn_open_text": "#020b05",
        "btn_cancel_bg": "#2b0e0e",
        "btn_cancel_hover": "#4a1818",
        "btn_cancel_text": "#ff4444",
        "btn_border_width": 1,
        "btn_border_color": "#00ff41",
        "progress_bg": "#0c2e15",
        "progress_fill": "#00ff41",
        "completed_fill": "#39ff14",
        "paused_fill": "#ccff00",
        "error_fill": "#ff3333",
        "badge_downloading": "#00ff41",
        "badge_completed": "#39ff14",
        "badge_paused": "#ccff00",
        "badge_error": "#ff3333",
        "badge_queued": "#256333",
        "badge_connecting": "#00b32c",
        "badge_cancelled": "#163a1f",
        "matrix_rain": True,
    }
}


def get_theme(theme_name: str) -> Dict[str, Any]:
    """Returns the color palette dictionary for the given theme name (case-insensitive)."""
    key = theme_name.lower().replace(" ", "_")
    return THEMES.get(key, THEMES["dark"])


def get_theme_display_names() -> list[str]:
    """Returns a list of user-facing theme display names."""
    return [t["display_name"] for t in THEMES.values()]


def normalize_theme_name(display_name: str) -> str:
    """Converts a display name like 'Cyberpunk' or 'Neo Tokyo' to internal key 'cyberpunk' or 'neo_tokyo'."""
    return display_name.lower().replace(" ", "_")


def set_window_icon(window: Any) -> None:
    """Sets custom Turbo Download Manager window titlebar and taskbar icon across Windows & Linux."""
    import os
    assets_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
    ico_path = os.path.join(assets_dir, "app_icon.ico")
    png_path = os.path.join(assets_dir, "app_icon.png")

    def _apply():
        if os.path.exists(ico_path):
            try:
                window.iconbitmap(ico_path)
            except Exception:
                pass
        if os.path.exists(png_path):
            try:
                from PIL import ImageTk, Image
                img = Image.open(png_path)
                photo = ImageTk.PhotoImage(img)
                window.iconphoto(True, photo)
                window._app_icon_photo = photo
            except Exception:
                pass

    _apply()
    # Schedule after 220ms to override CustomTkinter's default 200ms icon timer on CTkToplevel
    if hasattr(window, "after"):
        try:
            window.after(220, _apply)
        except Exception:
            pass